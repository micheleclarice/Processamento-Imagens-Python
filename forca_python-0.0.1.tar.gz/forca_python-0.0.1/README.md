# Pacotes_Python
Descomplicando a criação de pacotes de processamento de imagens em Python

## Description

Jogo da forca feito em Python